import styles from './CardItem.module.css';

function CardItem({ imagem, titulo, subtitulo, descricao }) {
  return (
    <div className={styles.card}>
      {/* Só mostra a imagem se o pai mandou a prop "imagem" */}
      {imagem && <img className={styles.imagem} src={imagem} alt={titulo} />}

      <div className={styles.conteudo}>
        <h3 className={styles.titulo}>{titulo}</h3>
        <p className={styles.subtitulo}>{subtitulo}</p>
        <p className={styles.descricao}>{descricao}</p>
      </div>
    </div>
  );
}

export default CardItem;
