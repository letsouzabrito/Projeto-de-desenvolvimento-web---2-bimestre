import { Link } from 'react-router-dom';
import styles from './Navbar.module.css';

function Navbar() {
  return (
    <nav className={styles.navbar}>
      <h1 className={styles.logo}>Mengão</h1>

      <ul className={styles.lista}>
        <li><Link className={styles.link} to="/">Home</Link></li>
        <li><Link className={styles.link} to="/titulos">Grandes Títulos</Link></li>
        <li><Link className={styles.link} to="/idolos">Ídolos</Link></li>
        <li><Link className={styles.link} to="/jogadores">Jogadores Atuais</Link></li>
        <li><Link className={styles.link} to="/jogos">Jogos Históricos</Link></li>
      </ul>
    </nav>
  );
}

export default Navbar;
