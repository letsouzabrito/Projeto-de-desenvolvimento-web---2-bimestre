import styles from './Rodape.module.css';

function Rodape() {
  return (
    <footer className={styles.rodape}>
      <p>Uma vez Flamengo, sempre Flamengo</p>
    </footer>
  );
}

export default Rodape;
