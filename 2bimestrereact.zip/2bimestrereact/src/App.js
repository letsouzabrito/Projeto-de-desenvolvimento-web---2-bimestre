import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Navbar from './components/Navbar';
import Rodape from './components/Rodape';

import Home from './pages/Home';
import GrandesTitulos from './pages/GrandesTitulos';
import Idolos from './pages/Idolos';
import JogadoresAtuais from './pages/JogadoresAtuais';
import JogosHistoricos from './pages/JogosHistoricos';

function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/titulos" element={<GrandesTitulos />} />
        <Route path="/idolos" element={<Idolos />} />
        <Route path="/jogadores" element={<JogadoresAtuais />} />
        <Route path="/jogos" element={<JogosHistoricos />} />
      </Routes>

      <Rodape />
    </BrowserRouter>
  );
}

export default App;
