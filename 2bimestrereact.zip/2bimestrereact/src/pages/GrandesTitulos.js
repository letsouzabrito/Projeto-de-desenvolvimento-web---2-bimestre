import CardItem from '../components/CardItem';
import styles from './GrandesTitulos.module.css';
import taca from '../assets/taca.jpg';

function GrandesTitulos() {
  return (
    <main className={styles.pagina}>
      <h2 className={styles.titulo}>Grandes Títulos</h2>
      <p className={styles.subtitulo}>As conquistas mais importantes do Mengão.</p>

      <div className={styles.cards}>
        <CardItem
          imagem={taca}
          titulo="Mundial de Clubes"
          subtitulo="1981"
          descricao="Em Tóquio, o Flamengo venceu o Liverpool por 3 a 0 e se tornou campeão do mundo."
        />
        <CardItem
          imagem={taca}
          titulo="Copa Libertadores"
          subtitulo="1981, 2019, 2022 e 2025"
          descricao="Com quatro taças, o Flamengo é o clube brasileiro com mais títulos da Libertadores."
        />
        <CardItem
          imagem={taca}
          titulo="Campeonato Brasileiro"
          subtitulo="1980, 1982, 1983, 1987, 1992, 2009, 2019, 2020, 2025 e 2026"
          descricao="Em 2025 o time foi campeão brasileiro apenas quatro dias depois de ganhar a Libertadores. Em 2019, o título brasileiro foi conquistado no dia seguinte da histórica virada em Lima. O Flamengo, atualmente, tem 10 títulos brasileiros."
        />
        <CardItem
          imagem={taca}
          titulo="Copa do Brasil"
          subtitulo="1990, 2006, 2013, 2022 e 2024"
          descricao="O Flamengo possui cinco títulos do torneio de mata-mata mais importante do país."
        />
      </div>
    </main>
  );
}

export default GrandesTitulos;
