import CardItem from '../components/CardItem';
import styles from './JogosHistoricos.module.css';

function JogosHistoricos() {
  return (
    <main className={styles.pagina}>
      <h2 className={styles.titulo}>Jogos Históricos</h2>
      <p className={styles.subtitulo}>Partidas que nenhum rubro-negro esquece.</p>

      <div className={styles.cards}>
        <CardItem
          titulo="Flamengo 3 x 0 Liverpool"
          subtitulo="13/12/1981 - Final do Mundial, Tóquio"
          descricao="Com dois gols de Nunes e um de Adílio, o Flamengo virou campeão do mundo."
        />
        <CardItem
          titulo="Flamengo 1 x 0 Athletico-PR"
          subtitulo="29/10/2022 - Final da Libertadores, Guayaquil"
          descricao="Em mais um dia histórico e predestinado, Gabigol conduz o Flamengo ao seu terceiro título da Libertadores."
        />
        <CardItem
          titulo="Flamengo 2 x 1 River Plate"
          subtitulo="23/11/2019 - Final da Libertadores, Lima"
          descricao="Perdendo até os 88 minutos, o Flamengo virou com dois gols de Gabigol nos últimos minutos."
        />
        <CardItem
          titulo="Flamengo 3 x 1 Chelsea"
          subtitulo="20/06/2025 - Mundial de Clubes, Filadélfia"
          descricao="Virada sobre o time inglês na fase de grupos do Mundial de Clubes, liderada pelo ídolo Bruno Henrique."
        />
        <CardItem
          titulo="Flamengo 1 x 0 Palmeiras"
          subtitulo="29/11/2025 - Final da Libertadores, Lima"
          descricao="Gol de cabeça do Danilo deu ao Flamengo o tetracampeonato da América, em cima do Palmeiras. Concretizando a frase “Ninguém morre nos devendo”."
        />
        <CardItem
          titulo="Flamengo 2 x 0 Cobreloa"
          subtitulo="23/11/1981 - Final da Libertadores, Montevidéu"
          descricao="Com dois gols de Zico, o Flamengo conquista sua primeira taça da América."
        />
        <CardItem
          titulo="Flamengo 3 x 1 Vasco"
          subtitulo="27/05/2001 - Final do Carioca, Rio de Janeiro"
          descricao="Com gol histórico do Petković aos 43 minutos do 2º tempo, o Flamengo torna-se tricampeão carioca consecutivo, sendo esse em cima do seu maior rival, Vasco."
        />
      </div>
    </main>
  );
}

export default JogosHistoricos;
