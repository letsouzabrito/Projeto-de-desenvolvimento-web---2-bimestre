import CardItem from '../components/CardItem';
import styles from './JogadoresAtuais.module.css';
import camisa from '../assets/camisa.jpg';

function JogadoresAtuais() {
  return (
    <main className={styles.pagina}>
      <h2 className={styles.titulo}>Jogadores Atuais</h2>
      <p className={styles.subtitulo}>Alguns destaques do elenco de 2026, comandado por Leonardo Jardim.</p>

      <div className={styles.cards}>
        <CardItem
          imagem={camisa}
          titulo="Arrascaeta"
          subtitulo="Meia - Uruguai"
          descricao="Camisa 10 e um dos maiores garçons do time. Tricampeão da Libertadores pelo clube e ídolo incontestável."
        />
        <CardItem
          imagem={camisa}
          titulo="Pedro"
          subtitulo="Centroavante - Brasil"
          descricao="Artilheiro do time, conhecido pela ótima finalização dentro da área."
        />
        <CardItem
          imagem={camisa}
          titulo="Lucas Paquetá"
          subtitulo="Meia - Brasil"
          descricao="Cria do Ninho do Urubu, voltou ao Flamengo depois de jogar na Europa."
        />
        <CardItem
          imagem={camisa}
          titulo="Bruno Henrique"
          subtitulo="Ponta - Brasil"
          descricao="Vindo do Santos em 2019, fez e faz história com o manto rubro-negro até hoje."
        />
        <CardItem
          imagem={camisa}
          titulo="Samuel Lino"
          subtitulo="Ponta - Brasil"
          descricao="Ponta rápido e driblador, joga aberto pelos lados do campo. Jogou na base do Mengão, foi para a Europa e voltou em 2025. Autor dos gols dos títulos brasileiros de 2025 e 2026."
        />
        <CardItem
          imagem={camisa}
          titulo="Danilo"
          subtitulo="Zagueiro - Brasil"
          descricao="Autor do gol do título da Libertadores de 2025, Danilo se tornou ídolo em seu primeiro ano de clube."
        />
        <CardItem
          imagem={camisa}
          titulo="Léo Pereira"
          subtitulo="Zagueiro - Brasil"
          descricao="Chegou ao clube em 2020, e mesmo sendo criticado pela torcida nos primeiros anos deu a volta por cima e se tornou ídolo e um dos principais jogadores do elenco."
        />
      </div>
    </main>
  );
}

export default JogadoresAtuais;
