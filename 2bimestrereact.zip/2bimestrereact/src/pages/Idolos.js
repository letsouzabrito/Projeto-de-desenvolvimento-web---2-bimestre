import CardItem from '../components/CardItem';
import styles from './Idolos.module.css';
import escudo from '../assets/escudo.png';

function Idolos() {
  return (
    <main className={styles.pagina}>
      <h2 className={styles.titulo}>Ídolos</h2>
      <p className={styles.subtitulo}>Jogadores que entraram para a história do clube.</p>

      <div className={styles.cards}>
        <CardItem
          imagem={escudo}
          titulo="Zico"
          subtitulo="Meia - Galinho de Quintino"
          descricao="Maior ídolo e maior artilheiro da história do Flamengo. Camisa 10 do time campeão do mundo em 1981."
        />
        <CardItem
          imagem={escudo}
          titulo="Júnior"
          subtitulo="Lateral e meia - Maestro"
          descricao="É o jogador que mais vezes vestiu a camisa do Flamengo e fez parte do time de 1981."
        />
        <CardItem
          imagem={escudo}
          titulo="Leandro"
          subtitulo="Lateral"
          descricao="Junto a Zico e Junior, conquistou o mundo em 1981 e sabe o que é ser Flamengo."
        />
        <CardItem
          imagem={escudo}
          titulo="Gabigol"
          subtitulo="Atacante"
          descricao="Fez os dois gols da virada na final da Libertadores de 2019 e o gol do título de 2022."
        />
        <CardItem
          imagem={escudo}
          titulo="Arrascaeta"
          subtitulo="Meia"
          descricao="Camisa 10 da Gávea, o sucessor de Zico."
        />
        <CardItem
          imagem={escudo}
          titulo="Bruno Henrique"
          subtitulo="Atacante"
          descricao="Desde 2019 sendo decisivo pelo Flamengo. Apelidado pela torcida de “Rei dos Clássicos”."
        />

      </div>
    </main>
  );
}

export default Idolos;
