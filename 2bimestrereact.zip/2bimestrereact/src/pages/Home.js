import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import maracana from '../assets/maracana.jpg';

function Home() {
  return (
    <main className={styles.home}>
      <section className={styles.destaque}>
        <div className={styles.textos}>
          <h2 className={styles.titulo}>Clube de Regatas do Flamengo</h2>
          <p className={styles.texto}>
            Fundado em 1895, no Rio de Janeiro, o Flamengo é o clube com a maior
            torcida do Brasil. Neste site você conhece os principais títulos,
            os ídolos, o elenco atual e os jogos que marcaram a história do Mengão.
          </p>
          <Link className={styles.botao} to="/titulos">Ver os títulos</Link>
        </div>

        <img className={styles.imagem} src={maracana} alt="Torcida do Flamengo no Maracanã" />
      </section>
    </main>
  );
}

export default Home;
